package week6day2;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class LearnCookies {
	public static String cookie;
	public static RequestSpecification inputRequest;
	@BeforeSuite
	public void extractCookies() {
		
		RestAssured.baseURI="https://dev273722.service-now.com/api/now/table";
		RestAssured.authentication=RestAssured.basic("admin","pmU/PqyU2V7-");
		Response response = RestAssured.get("incident");
		 cookie = response.getCookie("JSESSIONID");
		 System.out.println(cookie);
	}
	@BeforeMethod
	public void setUp() {
		RestAssured.baseURI="https://dev273722.service-now.com/api/now/table";
	   inputRequest = RestAssured.given().contentType("application/json").cookie("JSESSIONID",cookie);
	}
	@Test
	public void createIncident() {
		
		Response response = inputRequest.post("incident");
		response.prettyPrint();
	}
	
	
	
	
	
	
	
	
	
	
	

}
