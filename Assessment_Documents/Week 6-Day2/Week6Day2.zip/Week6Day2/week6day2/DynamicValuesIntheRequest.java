package week6day2;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DynamicValuesIntheRequest {

	Faker fake=new Faker();
	
	//@Test
	public void createBooking() {
    Map<String,Object> m1=new HashMap<String,Object>();	
    m1.put("firstname",fake.name().firstName());
    m1.put("lastname",fake.name().lastName());
    m1.put("totalprice", fake.number().numberBetween(100, 150));
    m1.put("depositpaid", true);
    m1.put("additionalneeds", "Breakfast");
    
    Map<String,Object> m2=new HashMap<String,Object>();	
    m2.put("checkin", "2018-01-01");
    m2.put("checkin", "2019-01-01");
    
    m1.put("bookingdates", m2);
    RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
    
    RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
    .when().body(m1);
    Response response = inputRequest.post();
    response.prettyPrint();
    
	}
	

}
