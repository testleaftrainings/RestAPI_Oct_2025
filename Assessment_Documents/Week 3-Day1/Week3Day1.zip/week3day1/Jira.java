package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Jira {

	@Test
	public void createIssue() {

		RestAssured.baseURI="";
		RestAssured.authentication=RestAssured.preemptive().basic("username","jirakey");











	}
}
