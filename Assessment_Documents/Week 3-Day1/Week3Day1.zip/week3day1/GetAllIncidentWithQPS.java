package week3day1;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentWithQPS {

	@Test
	public void allIncidents() {


		//Endpoint 	

		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";

		//Authentication

		RestAssured.authentication=RestAssured.basic("admin", "k6C8-ajUWqY%");
		
		//Form request --Multiple query parameter
		
		Map<String,String>qp=new HashMap<String,String>();
		qp.put("sysparm_limit", "5");
		qp.put("sysparm_fields", "sys_id,short_description");
		
		RequestSpecification inputRequest = RestAssured.given().queryParams(qp);

		//Send Request
		
		Response response = inputRequest.get("incident");
		
		//print the respons e
		response.prettyPrint();
		
		
		
		




	}
}
