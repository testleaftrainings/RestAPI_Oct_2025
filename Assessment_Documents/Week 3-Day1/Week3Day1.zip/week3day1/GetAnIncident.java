package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAnIncident {

	@Test
	public void allIncidents() {


		//Endpoint 	

		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";

		//Authentication

		RequestSpecification inputRequest = RestAssured.given().header("Authorization","Basic YWRtaW46azZDOC1halVXcVkl");

		//Send Request
		
		Response response = inputRequest.get("incident/ffcb3308473002100b45d48f016d43bf");
		
		//print the respons e
		response.prettyPrint();
		
		
		
		




	}
}
