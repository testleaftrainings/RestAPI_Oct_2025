package week3day1;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithFile {

	@Test
	public void createWithFile() {

		//Endpoint 	
		
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "k6C8-ajUWqY%");
		
		File filePath=new File("./src/test/resources/createincident.json");
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when()
		.body(filePath);
		
		Response response = inputRequest.post("incident");
		
		response.prettyPrint();
		
		
		
		
		
		
	}
}
