package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident {
     
	@Test
	public void delete() {
	
		//Endpoint 	
		
				RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
				
				//Authentication
				
				RestAssured.authentication=RestAssured.basic("admin", "k6C8-ajUWqY%");
				
				//Send Request
				
				Response response = RestAssured.delete("incident/db446055476202100b45d48f016d4343");
				
				// Get Status code
				
				int statusCode = response.getStatusCode();
				
				//Print status code
				
				System.out.println("Status code for delete is -----"+statusCode);
				
				
				
				
				
				
				
		
	}
}
