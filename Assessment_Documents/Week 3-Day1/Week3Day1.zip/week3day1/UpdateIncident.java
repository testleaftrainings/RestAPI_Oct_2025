package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {

	@Test
	public void update() {
	
		//Endpoint 	
		
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "k6C8-ajUWqY%");
		
		
		//Form Request Body
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when()
		.body("\r\n"
				+ "{\r\n"
				+ "    \"short_description\": \"Update using Postman\",\r\n"
				+ "    \"description\": \"Update Laptop charging problem\"\r\n"
				+ "}");
		
		//Send Request
		
		Response response = inputRequest.put("incident/db446055476202100b45d48f016d4343");
		
		//Print Response
		response.prettyPrint();
		
		
		
	}
}
