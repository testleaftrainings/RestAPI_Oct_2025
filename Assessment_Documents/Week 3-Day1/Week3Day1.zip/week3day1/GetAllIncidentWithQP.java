package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentWithQP {

	@Test
	public void allIncidents() {


		//Endpoint 	

		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";

		//Authentication

		RestAssured.authentication=RestAssured.basic("admin", "k6C8-ajUWqY%");
		
		//Form request --Single query parameter
		RequestSpecification inputRequest = RestAssured.given().queryParam("sysparm_fields","sys_id");

		//Send Request
		
		Response response = inputRequest.get("incident");
		
		//print the respons e
		response.prettyPrint();
		
		
		
		




	}
}
